import 'package:dio/dio.dart';

class API {
  final dio = Dio();
  final String baseUrl = "https://key1.tech/api";
  login({required email, required password}) async {
    try {
      final String url = "$baseUrl/login";
      final params = {"email": email, "password": password};

      final response = await dio.post(
        url,
        data: FormData.fromMap(params),
      );
      return response.data;
    } catch (e) {
      return e;
    }
  }

  register({
    required email,
    required password,
    required name,
  }) async {
    try {
      final String url = "$baseUrl/register";
      final params = {
        "name": name,
        "email": email,
        "password": password,
      };

      final formdata = await dio.post(
        url,
        data: FormData.fromMap(params),
      );
      return formdata.data;
    } catch (e) {
      return e;
    }
  }
}
