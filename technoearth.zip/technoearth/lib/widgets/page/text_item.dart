import 'package:flutter/material.dart';

class Textitem extends StatelessWidget {
  final Icon icon;
  final String text;
  final bool safe;
  final double width;
  final double height;
  final TextEditingController controller;
  const Textitem({
    super.key,
    required this.icon,
    required this.text,
    required this.safe,
    required this.width,
    required this.height,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: TextFormField(
          decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: Theme.of(context)
                        .colorScheme
                        .onBackground
                        .withAlpha(150)),
                borderRadius: BorderRadius.circular(30),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                    color: Theme.of(context)
                        .colorScheme
                        .onBackground
                        .withAlpha(150)),
                borderRadius: BorderRadius.circular(30),
              ),
              iconColor: Theme.of(context).colorScheme.primary.withAlpha(150),
              prefixIcon: icon,
              hintText: text,
              hintStyle: TextStyle(
                fontSize: 15,
                color: Theme.of(context).colorScheme.primary.withAlpha(150),
              )),
          obscureText: safe,
          controller: controller,
        ),
      ),
    );
  }
}
