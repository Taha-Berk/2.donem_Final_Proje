import 'package:flutter/material.dart';

class Logo extends StatelessWidget {
  final double width;
  final double height;
  final double size;
  final double Isize;

  const Logo({
    super.key,
    required this.width,
    required this.height,
    required this.size,
    required this.Isize,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: Colors.red,
        border: Border.all(
          width: 2,
          color: Colors.grey,
        ),
        borderRadius: BorderRadius.circular(25),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 5,
          ),
          Text(
            "TechnoEarth",
            style: TextStyle(color: Colors.white, fontSize: size),
          ),
          SizedBox(
            width: 5,
          ),
          Icon(
            Icons.rocket_launch,
            color: Colors.white,
            size: Isize,
          ),
          SizedBox(
            width: 5,
          ),
        ],
      ),
    );
  }
}
