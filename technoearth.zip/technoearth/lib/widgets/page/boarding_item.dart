import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';

class BoardingItem extends StatelessWidget {
  final String image;
  final String title;

  const BoardingItem({
    super.key,
    required this.image,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: Padding(
        padding: const EdgeInsets.all(38.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Image.network(
              image,
              width: 150,
            ),
            Column(
              children: [
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary.withAlpha(150),
                    fontSize: 20,
                  ),
                ),
                const Gap(80),
                ElevatedButton(
                  onPressed: () => context.push("/welcome"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        Theme.of(context).colorScheme.primary.withAlpha(150),
                  ),
                  child: Text(
                    "Get Started",
                    style: TextStyle(
                      color: Theme.of(context)
                          .colorScheme
                          .primaryContainer
                          .withAlpha(150),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
