import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

import '../../bloc/client/client_cubit.dart';

class Loginbutton extends StatelessWidget {
  final String text;
  final String image;
  final Function()? ontap;
  const Loginbutton({
    super.key,
    required this.clientCubit,
    required this.text,
    required this.image,
    this.ontap,
  });

  final ClientCubit clientCubit;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: InkWell(
        onTap: ontap,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (clientCubit.state.darkMode)
              Container(
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary.withAlpha(150),
                  border: Border.all(color: Colors.white),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Row(
                          children: [
                            Image(image: AssetImage(image)),
                            const Gap(10),
                            Text(
                              text,
                              style: const TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              Container(
                decoration: BoxDecoration(
                  border: Border.all(),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Row(
                          children: [
                            Image(image: AssetImage(image)),
                            const Gap(10),
                            Text(
                              text,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
