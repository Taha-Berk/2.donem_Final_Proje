import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/client/client_cubit.dart';
import '../../core/localizations.dart';
import '../../core/storage.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  File? file;
  uploadPhoto() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? selectedFile =
          await picker.pickImage(source: ImageSource.gallery);
      if (selectedFile == null) {
        return;
      }

      final String fileFormat =
          await selectedFile.name.split(".").last.toLowerCase();
      final img.Image? imageBytes;

      switch (fileFormat) {
        case ("jpg"):
          imageBytes = img.decodeJpg(File(selectedFile.path).readAsBytesSync());
        case ("jpeg"):
          imageBytes = img.decodeJpg(File(selectedFile.path).readAsBytesSync());
        case ("png"):
          imageBytes = img.decodePng(File(selectedFile.path).readAsBytesSync());
        case ("bmp"):
          imageBytes = img.decodeBmp(File(selectedFile.path).readAsBytesSync());
        case ("gif"):
          imageBytes = img.decodeGif(File(selectedFile.path).readAsBytesSync());
        case ("tiff"):
          imageBytes =
              img.decodeTiff(File(selectedFile.path).readAsBytesSync());
        default:
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text(
                AppLocalizations.of(context).getTranslate("photo_type"),
                style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                    color: Theme.of(context)
                        .colorScheme
                        .onBackground
                        .withAlpha(150)),
              ),
              content: Text(
                AppLocalizations.of(context).getTranslate("photo_type_text"),
                style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                    color: Theme.of(context)
                        .colorScheme
                        .onBackground
                        .withAlpha(150)),
              ),
            ),
          );
          return;
      }

      if (imageBytes == null) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(
              AppLocalizations.of(context).getTranslate("photo_type"),
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onBackground
                      .withAlpha(150)),
            ),
            content: Text(
              AppLocalizations.of(context).getTranslate("photo_type_text"),
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onBackground
                      .withAlpha(150)),
            ),
          ),
        );
        return;
      }

      if (imageBytes.width < 400 || imageBytes.height < 400) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(
              AppLocalizations.of(context).getTranslate("photo_size"),
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onBackground
                      .withAlpha(150)),
            ),
            content: Text(
              AppLocalizations.of(context).getTranslate("photo_size_text"),
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onBackground
                      .withAlpha(150)),
            ),
          ),
        );
        return;
      }

      final resizedImage;

      if (imageBytes.width > imageBytes.height) {
        resizedImage = img.copyResize(imageBytes, height: 400);
      } else {
        resizedImage = img.copyResize(imageBytes, width: 400);
      }

      List<int> resizedBytes = img.encodeJpg(
        resizedImage,
        quality: 85,
      );

      final Directory appTempDir = await getTemporaryDirectory();
      File finalFinal = File("${appTempDir.path}/avt.jpg");

      finalFinal.writeAsBytesSync(resizedBytes);

      setState(() {
        file = finalFinal;
      });
    } on Exception catch (e) {
      print("Hata");
      print(e);
    }
  }

  late ClientCubit clientCubit;
  late HaberCubit haberCubit;

  @override
  void initState() {
    super.initState();
    clientCubit = context.read<ClientCubit>();
    haberCubit = context.read<HaberCubit>();
    checkLogin();
  }

  Map<String, dynamic> user = {
    "name": "",
    "id": -1,
    "avatar": "",
    "email": "",
  };

  checkLogin() async {
    Storage storage = Storage();
    final user = await storage.loadUser();

    if (user != null) {
      setState(() {
        this.user = user;
      });
    } else {
      context.push("/welcome");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  if (file != null)
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withAlpha(150),
                          width: 3,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: CircleAvatar(
                        backgroundImage: FileImage(file!),
                        backgroundColor: Colors.white38,
                        maxRadius: 60,
                      ),
                    )
                  else
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withAlpha(150),
                          width: 3,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: CircleAvatar(
                        backgroundColor: Colors.white38,
                        maxRadius: 60,
                      ),
                    ),
                  const Gap(20),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "${user["name"]}",
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      Text(
                        AppLocalizations.of(context).getTranslate("user"),
                        style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onBackground
                                .withAlpha(150)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(),
            const Gap(10),
            Column(
              children: [
                InkWell(
                  onTap: () => uploadPhoto(),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        const Icon(Icons.add_a_photo_outlined),
                        const Gap(10),
                        Text(AppLocalizations.of(context)
                            .getTranslate("add_photo"))
                      ],
                    ),
                  ),
                ),
                const Gap(10),
                const Divider(),
                const Gap(10),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      const Icon(Icons.mail_outline),
                      const Gap(10),
                      Text(
                        AppLocalizations.of(context)
                                .getTranslate("profile-mail") +
                            " ${user["email"]}@example.com",
                      )
                    ],
                  ),
                ),
                const Gap(10),
                const Divider(),
                const Gap(10),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      const Icon(Icons.lock_outline),
                      const Gap(10),
                      Text(
                        AppLocalizations.of(context)
                                .getTranslate("profile-password") +
                            " ******",
                      )
                    ],
                  ),
                ),
                const Gap(10),
              ],
            ),
            const Divider(),
            const Gap(20),
            Expanded(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Divider(),
                ListTile(
                  leading: const Icon(
                    Icons.arrow_back,
                  ),
                  title: Text(
                    AppLocalizations.of(context).getTranslate("back"),
                  ),
                  onTap: () {
                    context.push("/home");
                  },
                ),
                const Divider(),
                ListTile(
                  leading: const Icon(
                    Icons.logout_outlined,
                  ),
                  title: Text(
                    AppLocalizations.of(context).getTranslate("logout"),
                  ),
                  onTap: () async {
                    Storage storage = Storage();
                    await storage.clearUser();

                    context.go("/welcome");
                  },
                ),
              ],
            ))
          ],
        ),
      ),
    );
  }
}
