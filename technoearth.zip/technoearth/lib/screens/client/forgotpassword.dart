import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/client/client_cubit.dart';
import '../../core/localizations.dart';
import '../../core/storage.dart';
import '../../services/api.dart';
import '../../widgets/page/logo.dart';
import '../../widgets/page/text_item.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  late ClientCubit clientCubit;
  late HaberCubit haberCubit;
  int Id = 0;
  bool loading = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordController1 = TextEditingController();
  TextEditingController nameController = TextEditingController();

  register() async {
    setState(() {
      Id++;
      loading = true;
    });
    API api = API();

    await api.register(
      email: emailController.text,
      password: passwordController.text,
      name: nameController.text,
    );

    Storage storage = Storage();
    await storage.saveUser(
      id: Id,
      name: nameController.text,
      email: emailController.text,
    );
    if (nameController.text == "" ||
        passwordController.text == "" ||
        passwordController1.text == "") {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            AppLocalizations.of(context).getTranslate("empty-information"),
            style: const TextStyle(color: Colors.white),
          ),
        ),
      );
    } else if (passwordController.text != passwordController1.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            AppLocalizations.of(context).getTranslate("wrong-password"),
            style: const TextStyle(color: Colors.white),
          ),
        ),
      );
    } else {
      context.push("/cPassword");
    }

    setState(() {
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    clientCubit = context.read<ClientCubit>();
    haberCubit = context.read<HaberCubit>();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ClientCubit, ClientState>(builder: (context, state) {
      return Scaffold(
        body: loading
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: Theme.of(context)
                            .colorScheme
                            .primary
                            .withAlpha(150),
                      ),
                    ],
                  ),
                ],
              )
            : SafeArea(
                child: SizedBox.expand(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 50, right: 60),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Padding(
                          padding: EdgeInsets.all(30.0),
                          child:
                              Logo(width: 300, height: 50, size: 30, Isize: 30),
                        ),
                        Textitem(
                            icon: const Icon(Icons.person_outline),
                            text: AppLocalizations.of(context)
                                .getTranslate("name"),
                            safe: false,
                            width: 300,
                            height: 70,
                            controller: nameController),
                        Textitem(
                            icon: const Icon(Icons.email_outlined),
                            text: AppLocalizations.of(context)
                                .getTranslate("enter-email"),
                            safe: false,
                            width: 300,
                            height: 70,
                            controller: emailController),
                        Textitem(
                            icon: const Icon(Icons.lock_outline),
                            text: AppLocalizations.of(context)
                                .getTranslate("enter-password3"),
                            safe: true,
                            width: 300,
                            height: 70,
                            controller: passwordController),
                        Textitem(
                            icon: const Icon(Icons.lock_outline),
                            text: AppLocalizations.of(context)
                                .getTranslate("enter-password4"),
                            safe: true,
                            width: 300,
                            height: 70,
                            controller: passwordController1),
                        Padding(
                          padding: const EdgeInsets.only(top: 30, bottom: 30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              InkWell(
                                onTap: () => register(),
                                child: Container(
                                  width: 300,
                                  height: 50,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onBackground
                                          .withAlpha(150),
                                    ),
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primary
                                        .withAlpha(150),
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        AppLocalizations.of(context)
                                            .getTranslate("change-password"),
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Gap(40),
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: InkWell(
                            child: Text(
                              AppLocalizations.of(context)
                                  .getTranslate("login"),
                              style: const TextStyle(color: Colors.lightBlue),
                            ),
                            onTap: () => context.push("/login"),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      );
    });
  }
}
