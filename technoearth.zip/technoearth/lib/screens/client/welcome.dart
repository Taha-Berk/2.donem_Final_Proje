import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:technoearth/widgets/page/logo.dart';
import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/client/client_cubit.dart';
import '../../core/localizations.dart';
import '../../widgets/page/login_button.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  late ClientCubit clientCubit;
  late HaberCubit haberCubit;
  TextEditingController ilKoduYoneticisi = TextEditingController(text: "34");

  @override
  void initState() {
    super.initState();
    clientCubit = context.read<ClientCubit>();
    haberCubit = context.read<HaberCubit>();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ClientCubit, ClientState>(builder: (context, state) {
      return Scaffold(
        body: SafeArea(
          child: SizedBox.expand(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Logo(width: 300, height: 50, size: 30, Isize: 30),
                const Gap(120),
                Loginbutton(
                  clientCubit: clientCubit,
                  text: AppLocalizations.of(context)
                      .getTranslate("continue-Email"),
                  image: "../assets/images/mailicon.png",
                  ontap: () => context.push("/login"),
                ),
                Loginbutton(
                  clientCubit: clientCubit,
                  text: AppLocalizations.of(context)
                      .getTranslate("continue-Google"),
                  image: "../assets/images/googleicon.png",
                ),
                Loginbutton(
                  clientCubit: clientCubit,
                  text: AppLocalizations.of(context)
                      .getTranslate("continue-Apple"),
                  image: "../assets/images/appleicon.png",
                ),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: InkWell(
                    child: Text(
                      AppLocalizations.of(context)
                          .getTranslate("continue-register"),
                      style: const TextStyle(color: Colors.lightBlue),
                    ),
                    onTap: () => context.push("/register"),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(bottom: 20, top: 50),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      if (clientCubit.state.darkMode)
                        Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: IconButton(
                            onPressed: () {
                              clientCubit.changeDarkMode(darkMode: false);
                            },
                            icon: const Icon(
                              Icons.sunny,
                            ),
                          ),
                        )
                      else
                        Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: IconButton(
                            onPressed: () {
                              clientCubit.changeDarkMode(darkMode: true);
                            },
                            icon: const Icon(Icons.nightlight),
                          ),
                        ),
                      if (clientCubit.state.darkMode)
                        IconButton(
                          onPressed: () {
                            showModalBottomSheet(
                              context: context,
                              builder: (context) => ListView(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 35),
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(18.0),
                                    child: Text(
                                      AppLocalizations.of(context)
                                          .getTranslate("select-language"),
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyLarge!
                                          .copyWith(
                                              fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  ListTile(
                                      title: const Text("Turkce"),
                                      leading: const Icon(Icons.language),
                                      enabled:
                                          clientCubit.state.language != "tr",
                                      subtitle: const Text("Turkish (Turkiye)"),
                                      onTap: () => clientCubit.changeLanguage(
                                          language: "tr")),
                                  ListTile(
                                    title: const Text("English"),
                                    enabled: clientCubit.state.language != "en",
                                    leading: const Icon(Icons.language),
                                    subtitle:
                                        const Text("English (United States)"),
                                    onTap: () => clientCubit.changeLanguage(
                                        language: "en"),
                                  ),
                                ],
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.language,
                          ),
                        )
                      else
                        IconButton(
                          onPressed: () {
                            showModalBottomSheet(
                              context: context,
                              builder: (context) => ListView(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 35),
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(18.0),
                                    child: Text(
                                      AppLocalizations.of(context)
                                          .getTranslate("select-language"),
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyLarge!
                                          .copyWith(
                                              fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  ListTile(
                                      title: const Text("Turkce"),
                                      leading: const Icon(Icons.language),
                                      enabled:
                                          clientCubit.state.language != "tr",
                                      subtitle: const Text("Turkish (Turkiye)"),
                                      onTap: () => clientCubit.changeLanguage(
                                          language: "tr")),
                                  ListTile(
                                    title: const Text("English"),
                                    enabled: clientCubit.state.language != "en",
                                    leading: const Icon(Icons.language),
                                    subtitle:
                                        const Text("English (United States)"),
                                    onTap: () => clientCubit.changeLanguage(
                                        language: "en"),
                                  ),
                                ],
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.language,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}
