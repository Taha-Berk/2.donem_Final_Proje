import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:technoearth/widgets/page/login_button.dart';
import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/client/client_cubit.dart';
import '../../core/localizations.dart';
import '../../core/storage.dart';
import '../../services/api.dart';
import '../../widgets/page/logo.dart';
import '../../widgets/page/text_item.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  late ClientCubit clientCubit;
  late HaberCubit haberCubit;
  TextEditingController ilKoduYoneticisi = TextEditingController(text: "34");
  bool loading = false;
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  login() async {
    setState(() {
      loading = true;
    });
    API Api = API();

    final response = await Api.login(
        email: emailController.text, password: passwordController.text);

    if (response is Exception) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            AppLocalizations.of(context).getTranslate("wrong-information"),
            style: const TextStyle(color: Colors.white),
          ),
        ),
      );
    } else {
      Storage storage = Storage();
      await storage.saveUser(
        id: response["data"]["user"]["id"],
        name: response["data"]["user"]["name"],
        email: response["data"]["user"]["email"],
      );
      await storage.saveToken(response["data"]["token"]);
      context.push("/home");
    }
    setState(() {
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    clientCubit = context.read<ClientCubit>();
    haberCubit = context.read<HaberCubit>();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ClientCubit, ClientState>(builder: (context, state) {
      return Scaffold(
        body: loading
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: Theme.of(context)
                            .colorScheme
                            .primary
                            .withAlpha(150),
                      ),
                    ],
                  ),
                ],
              )
            : SafeArea(
                child: SizedBox.expand(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 50, right: 60),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Padding(
                          padding: EdgeInsets.all(30.0),
                          child:
                              Logo(width: 300, height: 50, size: 30, Isize: 30),
                        ),
                        Textitem(
                          icon: const Icon(Icons.email_outlined),
                          text: AppLocalizations.of(context)
                              .getTranslate("enter-email"),
                          safe: false,
                          width: 300,
                          height: 70,
                          controller: emailController,
                        ),
                        Textitem(
                          icon: const Icon(Icons.lock_outline),
                          text: AppLocalizations.of(context)
                              .getTranslate("enter-password"),
                          safe: true,
                          width: 300,
                          height: 70,
                          controller: passwordController,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(20.0),
                              child: InkWell(
                                child: Text(
                                  AppLocalizations.of(context)
                                      .getTranslate("forgot-password"),
                                  style: const TextStyle(
                                    color: Colors.lightBlue,
                                  ),
                                  textAlign: TextAlign.right,
                                ),
                                onTap: () => context.push("/forgot"),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () => login(),
                              child: Container(
                                width: 300,
                                height: 50,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onBackground
                                        .withAlpha(150),
                                  ),
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withAlpha(150),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      AppLocalizations.of(context)
                                          .getTranslate("Sign-in"),
                                      style:
                                          const TextStyle(color: Colors.white),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Gap(50),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Loginbutton(
                              clientCubit: clientCubit,
                              text: "Google",
                              image: "../assets/images/googleicon.png",
                            ),
                            Loginbutton(
                              clientCubit: clientCubit,
                              text: "Apple",
                              image: "../assets/images/appleicon.png",
                            ),
                          ],
                        ),
                        const Gap(60),
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: InkWell(
                            child: Text(
                              AppLocalizations.of(context)
                                  .getTranslate("continue-register"),
                              style: const TextStyle(color: Colors.lightBlue),
                            ),
                            onTap: () => context.push("/register"),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      );
    });
  }
}
