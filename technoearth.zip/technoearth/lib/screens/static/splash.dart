import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:technoearth/core/data.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Map<String, dynamic> pageData = {};

  load() async {
    AppData dataManager = AppData();

    final data = await dataManager.getSplashData();

    setState(() {
      pageData = data;
    });

    Future.delayed(Duration(seconds: pageData["delay"]), () {
      context.go("/loader");
    });
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) {
    return pageData.isEmpty
        ? const SizedBox()
        : Scaffold(
            body: SafeArea(
              child: SizedBox.expand(
                child: Stack(
                  children: [
                    Container(
                      width: double.infinity,
                      height: double.infinity,
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              pageData["logo"],
                              width: 120,
                            ),
                            Gap(100),
                            Align(
                              child: CircularProgressIndicator(
                                color: Theme.of(context)
                                    .colorScheme
                                    .primary
                                    .withAlpha(150),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }
}
