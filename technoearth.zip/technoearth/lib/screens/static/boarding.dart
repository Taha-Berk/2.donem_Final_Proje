import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:preload_page_view/preload_page_view.dart';
import '../../widgets/page/boarding_item.dart';

class BoardingScreen extends StatefulWidget {
  const BoardingScreen({super.key});

  @override
  State<BoardingScreen> createState() => _BoardingScreenState();
}

class _BoardingScreenState extends State<BoardingScreen> {
  final boardingData = [
    {
      "image": "/assets/images/Logo.png",
      "title": "The number one address for technology news",
    },
    {
      "image": "/assets/images/boarding_image_2.png",
      "title":
          "By registering, you can add the news on your home page to your favorites.",
    },
    {
      "image": "/assets/images/boarding_image_3.png",
      "title":
          "You can add your favorite news channel to your favorites and view its news from the search section.",
    },
  ];

  int page = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: PreloadPageView.builder(
          itemCount: boardingData.length,
          preloadPagesCount: boardingData.length,
          onPageChanged: (value) {
            setState(() {
              page = value;
            });
          },
          itemBuilder: (context, index) => BoardingItem(
            image: boardingData[index]["image"]!,
            title: boardingData[index]["title"]!,
          ),
        ),
      ),
      bottomNavigationBar: SizedBox(
        height: 70,
        child: Align(
          alignment: Alignment.center,
          child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: boardingData.length,
            itemBuilder: (context, index) => Icon(
              color: Theme.of(context).colorScheme.primary.withAlpha(150),
              page == index
                  ? CupertinoIcons.circle_filled
                  : CupertinoIcons.circle,
            ),
          ),
        ),
      ),
    );
  }
}
