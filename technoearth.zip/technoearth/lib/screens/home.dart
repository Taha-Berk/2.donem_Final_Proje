import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/client/client_cubit.dart';
import '../../bloc/haberler/haberler_cubit.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/localizations.dart';
import '../core/storage.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List haberler = [];

  Future<void> newsRead() async {
    final String response =
        await rootBundle.loadString('assets/data/Data.json');
    final data = await json.decode(response);
    setState(() {
      haberler = data["news"];
    });
  }

  late HaberlerCubit haberlerCubit;
  late HaberCubit haberCubit;
  late ClientCubit clientCubit;

  @override
  void initState() {
    super.initState();
    haberlerCubit = context.read<HaberlerCubit>();
    haberCubit = context.read<HaberCubit>();
    clientCubit = context.read<ClientCubit>();
    checkLogin();
    newsRead();
  }

  Map<String, dynamic> user = {
    "name": "",
    "id": -1,
    "avatar": "",
    "email": "",
  };

  reach() {
    final Uri uri = Uri.parse("https://github.com/Taha-Berk");
    launchUrl(uri);
  }

  checkLogin() async {
    Storage storage = Storage();
    final user = await storage.loadUser();

    if (user != null) {
      setState(() {
        this.user = user;
      });
    } else {
      context.go("/welcome");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Theme.of(context)
                            .colorScheme
                            .primary
                            .withAlpha(150),
                        width: 3,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: const CircleAvatar(
                      backgroundColor: Colors.white38,
                      maxRadius: 60,
                    ),
                  ),
                  const Gap(20),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "${user["name"]}",
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      Text(
                        AppLocalizations.of(context).getTranslate("user"),
                        style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onBackground
                                .withAlpha(150)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.person_2,
              ),
              title: Text(
                AppLocalizations.of(context).getTranslate("profile"),
              ),
              onTap: () {
                context.push("/profile");
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(
                Icons.home,
              ),
              title: Text(
                AppLocalizations.of(context).getTranslate("home"),
              ),
              onTap: () {},
            ),
            ListTile(
              leading: const Icon(
                Icons.privacy_tip,
              ),
              title: Text(
                AppLocalizations.of(context).getTranslate("privacy"),
              ),
              onTap: () {
                context.push("/privacy");
              },
            ),
            const Divider(),
            ListTile(
                leading: const Icon(Icons.contact_phone),
                title: Text(
                  AppLocalizations.of(context).getTranslate("contact"),
                ),
                onTap: () => reach()),
            const Divider(),
            ListTile(
              leading: const Icon(
                Icons.language,
              ),
              title: Text(
                AppLocalizations.of(context).getTranslate("language"),
              ),
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  builder: (context) => ListView(
                    padding: const EdgeInsets.symmetric(vertical: 35),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(18.0),
                        child: Text(
                          AppLocalizations.of(context)
                              .getTranslate("select-language"),
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                      ListTile(
                          title: const Text("Turkce"),
                          leading: const Icon(Icons.language),
                          enabled: clientCubit.state.language != "tr",
                          subtitle: const Text("Turkish (Turkiye)"),
                          onTap: () =>
                              clientCubit.changeLanguage(language: "tr")),
                      ListTile(
                        title: const Text("English"),
                        enabled: clientCubit.state.language != "en",
                        leading: const Icon(Icons.language),
                        subtitle: const Text("English (United States)"),
                        onTap: () => clientCubit.changeLanguage(language: "en"),
                      ),
                    ],
                  ),
                );
              },
            ),
            SwitchListTile(
              value: clientCubit.state.darkMode,
              onChanged: (value) {
                clientCubit.changeDarkMode(darkMode: value);
              },
              secondary: clientCubit.state.darkMode
                  ? const Icon(Icons.sunny)
                  : const Icon(Icons.nightlight),
              title: Text(
                AppLocalizations.of(context).getTranslate("night-mode"),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.logout_outlined,
              ),
              title: Text(
                AppLocalizations.of(context).getTranslate("logout"),
              ),
              onTap: () async {
                Storage storage = Storage();
                await storage.clearUser();

                context.go("/welcome");
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        actions: [
          Row(
            children: [
              IconButton(
                onPressed: () => context.push("/search"),
                icon: Icon(
                  Icons.search_outlined,
                ),
              ),
              const Gap(20),
              IconButton(
                onPressed: () => context.push("/favorites"),
                icon: Icon(
                  Icons.favorite_outline,
                ),
              ),
              const Gap(20),
            ],
          ),
        ],
      ),
      body:
          BlocBuilder<HaberlerCubit, HaberlerState>(builder: (context, state) {
        return ListView.builder(
          itemCount: haberler.length,
          itemBuilder: (context, index) => Container(
              margin: const EdgeInsets.all(14.0),
              padding: const EdgeInsets.all(14.0),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .colorScheme
                            .primary
                            .withAlpha(150),
                        border: Border.all(
                          width: 0.1,
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withAlpha(150),
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                            ),
                            child: Image(
                              image: AssetImage(
                                haberler[index]["photo"].toString(),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 18,
                                  child: Text(
                                    haberler[index]["channel_photo"].toString(),
                                  ),
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  haberler[index]["name"].toString(),
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey.shade200),
                                ),
                              ],
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 10, bottom: 10, left: 20, right: 10),
                                child: RichText(
                                  text: TextSpan(
                                      text: haberler[index]["text"].toString(),
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 10)),
                                  maxLines: 5,
                                ),
                              ),
                            ],
                          ),
                          const Divider(),
                          if (haberlerCubit
                              .isFavorite(haberler[index]["id"] as int))
                            const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Icon(
                                Icons.favorite,
                                color: Colors.red,
                              ),
                            )
                          else
                            const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Icon(
                                Icons.favorite_border,
                              ),
                            )
                        ],
                      ),
                    ),
                  ),
                ],
              )),
        );
      }),
    );
  }
}
