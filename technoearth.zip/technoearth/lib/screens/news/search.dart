import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/client/client_cubit.dart';
import '../../bloc/haberler/haberler_cubit.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/localizations.dart';
import '../../core/storage.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  var haberler = [
    {
      "id": 1,
      "kanalAd": "A haber",
      "haberyazisi":
          "Çin, uzaktan algılama özellikli Yaogan-41 uydusunu fırlattı",
      "kanalResim": "A",
    },
    {
      "id": 2,
      "kanalAd": "B haber",
      "haberyazisi": "NASA'nın uzay aracının dünya ile bağlantısı kesildi",
      "kanalResim": "B",
    },
    {
      "id": 3,
      "kanalAd": "C haber",
      "haberyazisi":
          "Kayak merkezi'nde yapay zeka teknolojisi kullanılmaya başlandı",
      "kanalResim": "C",
    },
    {
      "id": 4,
      "kanalAd": "D haber",
      "haberyazisi":
          "İngiltere'deki yargıçlar davalarda yapay zeka kullanabilecek",
      "kanalResim": "D",
    },
  ];

  late HaberlerCubit haberlerCubit;
  late HaberCubit haberCubit;
  late ClientCubit clientCubit;

  @override
  void initState() {
    super.initState();
    haberlerCubit = context.read<HaberlerCubit>();
    haberCubit = context.read<HaberCubit>();
    clientCubit = context.read<ClientCubit>();
    checkLogin();
  }

  Map<String, dynamic> user = {
    "name": "",
    "id": -1,
    "avatar": "",
    "email": "",
  };

  reach() {
    final Uri uri = Uri.parse("https://github.com/Taha-Berk");
    launchUrl(uri);
  }

  checkLogin() async {
    Storage storage = Storage();
    final user = await storage.loadUser();

    if (user != null) {
      setState(() {
        this.user = user;
      });
    } else {
      context.push("/welcome");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Row(
            children: [
              const Gap(20),
              IconButton(
                onPressed: () => context.push("/favorites"),
                icon: Icon(
                  Icons.favorite_outline,
                ),
              ),
              const Gap(20),
            ],
          ),
        ],
      ),
      body:
          BlocBuilder<HaberlerCubit, HaberlerState>(builder: (context, state) {
        return ListView.builder(
          itemCount: haberler.length,
          itemBuilder: (context, index) => Container(
              margin: const EdgeInsets.all(14.0),
              padding: const EdgeInsets.all(14.0),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .colorScheme
                            .primary
                            .withAlpha(150),
                        border: Border.all(
                          width: 0.1,
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withAlpha(150),
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: CircleAvatar(
                              radius: 50,
                              child: Text(
                                haberler[index]["kanalResim"].toString(),
                                style: TextStyle(fontSize: 30),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  haberler[index]["kanalAd"].toString(),
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey.shade200),
                                ),
                              ],
                            ),
                          ),
                          const Divider(),
                          if (haberlerCubit
                              .isFavorite(haberler[index]["id"] as int))
                            IconButton(
                                onPressed: () {
                                  haberlerCubit.removeFromFavorites(
                                      haberler[index]["id"] as int);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        AppLocalizations.of(context)
                                            .getTranslate(
                                                "remove_to_favorites"),
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                    ),
                                  );
                                },
                                icon: const Icon(
                                  Icons.favorite,
                                  color: Colors.red,
                                ))
                          else
                            IconButton(
                                onPressed: () {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        AppLocalizations.of(context)
                                            .getTranslate("add_to_favorites"),
                                        style: const TextStyle(
                                            color: Colors.white),
                                      ),
                                    ),
                                  );
                                  haberlerCubit.addToFavorites(haberler[index]);
                                },
                                icon: const Icon(Icons.favorite_border))
                        ],
                      ),
                    ),
                  ),
                ],
              )),
        );
      }),
    );
  }
}

class newsItem extends StatelessWidget {
  const newsItem({
    super.key,
    required this.Data,
    required this.text,
    required this.name,
    required this.photo,
  });

  final Data;
  final String text;
  final String name;
  final String photo;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primary.withAlpha(150),
          border: Border.all(
            width: 0.1,
            color: Theme.of(context).colorScheme.primary.withAlpha(150),
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 18,
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Row(
                children: [
                  Text(
                    name,
                    style: TextStyle(fontSize: 13, color: Colors.grey.shade200),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      top: 10, bottom: 10, left: 20, right: 10),
                  child: RichText(
                    text: TextSpan(
                        text: text,
                        style: TextStyle(color: Colors.white, fontSize: 10)),
                    maxLines: 5,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
