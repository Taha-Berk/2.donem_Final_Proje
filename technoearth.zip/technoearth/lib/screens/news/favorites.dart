import 'package:flutter/material.dart';

import '../../bloc/haber/haber_cubit.dart';
import '../../bloc/haberler/haberler_cubit.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/localizations.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late HaberlerCubit haberlerCubit;
  late HaberCubit haberCubit;

  @override
  void initState() {
    super.initState();
    haberlerCubit = context.read<HaberlerCubit>();
    haberCubit = context.read<HaberCubit>();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context).getTranslate("favorites")),
      ),
      body:
          BlocBuilder<HaberlerCubit, HaberlerState>(builder: (context, state) {
        return SizedBox.expand(
          child: state.favorites.length == 0
              ? Center(
                  child: Text(AppLocalizations.of(context)
                      .getTranslate("favorites-empty")))
              : ListView.builder(
                  itemCount: state.favorites.length,
                  itemBuilder: (context, index) => Container(
                    margin: const EdgeInsets.all(14.0),
                    padding: const EdgeInsets.all(14.0),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .primary
                              .withAlpha(150),
                          border: Border.all(
                            width: 0.1,
                            color: Theme.of(context)
                                .colorScheme
                                .primary
                                .withAlpha(150),
                          ),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: CircleAvatar(
                                radius: 50,
                                child: Text(
                                  state.favorites[index]["kanalResim"]
                                      .toString(),
                                  style: const TextStyle(fontSize: 30),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 5,
                                  ),
                                  Text(
                                    state.favorites[index]["kanalAd"]
                                        .toString(),
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey.shade200),
                                  ),
                                ],
                              ),
                            ),
                            const Divider(),
                            if (haberlerCubit.isFavorite(
                                state.favorites[index]["id"] as int))
                              IconButton(
                                  onPressed: () {
                                    haberlerCubit.removeFromFavorites(
                                        state.favorites[index]["id"] as int);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          AppLocalizations.of(context)
                                              .getTranslate(
                                                  "remove_to_favorites"),
                                          style: const TextStyle(
                                              color: Colors.white),
                                        ),
                                      ),
                                    );
                                  },
                                  icon: const Icon(
                                    Icons.favorite,
                                    color: Colors.red,
                                  ))
                            else
                              IconButton(
                                  onPressed: () {
                                    haberlerCubit.addToFavorites(
                                      state.favorites[index],
                                    );
                                  },
                                  icon: const Icon(Icons.favorite_border))
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
        );
      }),
    );
  }
}
