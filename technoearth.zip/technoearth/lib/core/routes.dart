import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:technoearth/screens/static/mainScreen.dart';
import 'package:technoearth/screens/static/splash.dart';
import '../screens/client/changepassword.dart';
import '../screens/client/forgotpassword.dart';
import '../screens/client/welcome.dart';
import '../screens/client/register.dart';
import '../screens/client/login.dart';
import '../screens/client/profile.dart';
import '../screens/core/error.dart';
import '../screens/core/loader.dart';
import '../screens/home.dart';
import '../screens/news/search.dart';
import '../screens/news/favorites.dart';
import '../screens/static/privacy.dart';
import '../screens/static/boarding.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();
final _sheelNavigatorKey = GlobalKey<NavigatorState>();

final routes = GoRouter(
  errorBuilder: (context, state) => const ErrorScreen(),
  navigatorKey: _rootNavigatorKey,
  routes: [
    ShellRoute(
        navigatorKey: _sheelNavigatorKey,
        builder: (context, state, child) => MainScreen(child: child),
        routes: [
          GoRoute(
            parentNavigatorKey: _sheelNavigatorKey,
            path: '/profile',
            builder: (context, state) => const ProfileScreen(),
          ),
          GoRoute(
            parentNavigatorKey: _sheelNavigatorKey,
            path: '/privacy',
            builder: (context, state) => const PrivacyScreen(),
          ),
          GoRoute(
            parentNavigatorKey: _sheelNavigatorKey,
            path: '/home',
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            parentNavigatorKey: _sheelNavigatorKey,
            path: "/search",
            builder: (context, state) => const SearchScreen(),
          ),
          GoRoute(
            parentNavigatorKey: _sheelNavigatorKey,
            path: "/favorites",
            builder: (context, state) => const FavoritesScreen(),
          ),
          GoRoute(
            parentNavigatorKey: _sheelNavigatorKey,
            path: "/search",
            builder: (context, state) => const SearchScreen(),
          ),
        ]),
    GoRoute(
      path: '/cPassword',
      builder: (context, state) => const ChangePasswordScreen(),
    ),
    GoRoute(
      path: '/forgot',
      builder: (context, state) => const ForgotPasswordScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/register',
      builder: (context, state) => const RegisterScreen(),
    ),
    GoRoute(
      path: '/loader',
      builder: (context, state) => const LoaderScreen(),
    ),
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/boarding',
      builder: (context, state) => const BoardingScreen(),
    ),
    GoRoute(
      path: '/welcome',
      builder: (context, state) => const WelcomeScreen(),
    ),
  ],
);
