import 'package:flutter_bloc/flutter_bloc.dart';

part 'haber_state.dart';

class HaberCubit extends Cubit<HaberState> {
  HaberCubit(super.initialState);

  haberEkle(
      {required int id,
      required String resim,
      required String kanalAd,
      required String haberyazisi,
      required String kanalResim}) {
    var haberler = state.haber;

    if (haberler.any((element) => element["id"] == id)) {
      haberler.firstWhere((element) => element["id"] == id)["count"]++;
    } else {
      haberler.add({
        "id": id,
        "resim": resim,
        "kanalAd": kanalAd,
        "haberyazisi": haberyazisi,
        "kanalResim": kanalResim,
      });
    }

    final yeniDurum = HaberState(
      haber: haberler,
    );
    emit(yeniDurum);
  }

  haberCikart({required int id}) {
    var haberler = state.haber;

    haberler.removeWhere((element) => element["id"] == id);

    final yeniDurum = HaberState(
      haber: haberler,
    );
    emit(yeniDurum);
  }

  haberiBosalt() {
    final yeniDurum = HaberState(
      haber: [],
    );
    emit(yeniDurum);
  }
}
