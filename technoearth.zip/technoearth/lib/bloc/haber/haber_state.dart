part of 'haber_cubit.dart';

class HaberState {
  final List<dynamic> haber;

  HaberState({required this.haber});
}
