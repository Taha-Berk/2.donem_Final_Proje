part of 'haberler_cubit.dart';

class HaberlerState {
  final List<Map<String, dynamic>> favorites;

  HaberlerState({this.favorites = const []});
}
