import 'package:flutter_bloc/flutter_bloc.dart';
part 'haberler_state.dart';

class HaberlerCubit extends Cubit<HaberlerState> {
  HaberlerCubit(super.initialState);

  addToFavorites(Map<String, dynamic> haber) {
    var currentFavorites = state.favorites;

    bool found = false;

    for (int i = 0; i < currentFavorites.length; i++) {
      if (currentFavorites[i]["id"] == haber["id"]) {
        found = true;
        break;
      }
    }

    if (found) {
    } else {
      currentFavorites.add(haber);
      final updatedState = HaberlerState(
        favorites: currentFavorites,
      );

      emit(updatedState);

      print("eklendi");
    }
  }

  addToFavorites2(Map<String, dynamic> haber) {
    var currentFavorites = state.favorites;

    if (currentFavorites.any((element) => element["id"] == haber["id"])) {
      // zaten var favori de o urun
    } else {
      currentFavorites.add(haber);
      final newState = HaberlerState(favorites: currentFavorites);
      emit(newState);
    }
  }

  bool isFavorite(int haberId) {
    return state.favorites.any((element) => element["id"] == haberId);
  }

  removeFromFavorites(int haberId) {
    var currentFavorites = state.favorites;

    currentFavorites.removeWhere((element) => element["id"] == haberId);

    final newState = HaberlerState(favorites: currentFavorites);

    emit(newState);
  }

  clearFavorites() {
    final updatedState = HaberlerState(
      favorites: const [],
    );

    emit(updatedState);
  }
}
