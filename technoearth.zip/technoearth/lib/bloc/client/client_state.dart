part of './client_cubit.dart';

class ClientState {
  final String language;
  final bool darkMode;

  ClientState({required this.language, required this.darkMode});
}
